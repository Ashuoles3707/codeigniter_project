<?php
namespace App\Controllers;
use App\Models\BookModel;
/**
 * 
 */
class Book extends BaseController
{
		public function index()
		{
			//$data=[];
			$session = \Config\Services::session();
			$data['session'] = $session;
			 echo view('books/list',$data);
		}
		public function create()
		{
			$session = \Config\Services::session();
			helper('from');

			$data=[];

			if($this->request->getMethod() == 'post'){
				$input = $this->validate([
					'name' => 'required|min_length[5]',
					'author' => 'required|min_length[5]',
				]);

				if($input == true){
					//successfull
					$model = new BookModel();

					$model->save([
						'name' => $this->request->getPost('name'),
						'author' => $this->request->getPost('author'),
						'isbn_no' => $this->request->getPost('isbn_no'),

					]);
					$session->setFlashdata('success','data successfull inserted');
					return redirect()->to('/books');
				}else{
					//error
					$data['validation'] = $this->validator;
				}
			}

			echo view('books/create',$data);
		}
}
?>