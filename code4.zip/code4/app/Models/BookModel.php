<?php
namespace App\Models;

use CodeIgniter\Model;

Class BookModel extends Model{

	protected $table = 'books';
	protected $allowedFields = ['title','author','isbn_no'];
}
?>