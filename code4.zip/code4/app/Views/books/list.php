<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Codeigniter 4 Application</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
</head>
<body>
<div class="container-fluid bg-purple shadow-sm">
	<div class="container pb-2 pt-2">
		<div class="text-white h4">Codeigniter 4 CURD Application</div>
	</div>
</div>

<div class="bg-white shadow-sm">
	<div class="container">
		<div class="row">
			<nav class="nav nav-underline">
				<div class="nav-link">Books / Views</div>
			</nav>
		</div>
	</div>

	<div class="container mt-4">
		<div class="row">

			<div class="col-md-12 text-right">
				<a href="<?php echo base_url('books/create') ?>" class="btn btn-primary">Add</a>
			</div>

			<div class="col-md-12">
				<?php
				if(!empty($session->getFlashdata('success'))){
				?>
				<div class="alert alert-success">
					<?php echo $session->getFlashdata('success') ?>
				</div>
				<?php
			}
			?>
			</div>
	</div>

	<div class="container mt-4">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
				<div class="card-header bg-purple text-white">
					<div class="nav-header-title">Books</div>
				</div>

				<div class="card-body">
					<table class="table table-striped">
						<tr>
							<th>Id</th>
							<th>Title</th>
							<th>Isbn_no</th>
							<th>Author</th>
							<th width="150">Action</th>
						</tr>
						<tr>
							<td>1</td>
							<td>Computer</td>
							<td>1234</td>
							<td>Ashutosh</td>
							<td>
								<a href="" class="btn btn-primary btn-sm">Edit</a>
								<a href="" class="btn btn-danger btn-sm">Delete</a>
							</td>
						</tr>
						<tr>
							<td>2</td>
							<td>Computer</td>
							<td>1234</td>
							<td>Ashutosh</td>
							<td>
								<a href="" class="btn btn-primary btn-sm">Edit</a>
								<a href="" class="btn btn-danger btn-sm">Delete</a>
							</td>
						</tr>
					</table>
				</div>
			</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>