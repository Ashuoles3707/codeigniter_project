<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Codeigniter 4 Application</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>">
</head>
<body>
<div class="container-fluid bg-purple shadow-sm">
	<div class="container pb-2 pt-2">
		<div class="text-white h4">Codeigniter 4 CURD Application</div>
	</div>
</div>

<div class="bg-white shadow-sm">
	<div class="container">
		<div class="row">
			<nav class="nav nav-underline">
				<div class="nav-link">Books / Create</div>
			</nav>
		</div>
	</div>

	<div class="container mt-4">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
				<div class="card-header bg-purple text-white">
					<div class="nav-header-title">Create</div>
				</div>

				<div class="card-body">
					<form  method="post" name="createForm" id="createForm">
					<div class="form-group">
						<label>Name</label>
						<input class="form-control" type="text" name="name" id="name" value="" placeholder="Name">
						<?php /*echo set_value('name');*/?>
						<?php 
						//is bootstrap validation this code copy and past input class  
						//(isset ($validation) && $validation->hasError('name')) ? 'is-invalid' : '' ; 

						
						 if(isset ($validation) && $validation->hasError('name')) 
						 {
						 	echo '<p style="color:red">'.$validation->getError('name').'</p>';

						 	//'<p class="invalid-feedback">'..'</p>'
						 }

						?>
					</div>

					<div class="form-group">
						<label>Author</label>
						<input type="text" name="author" class="form-control" id="author" value="" placeholder="Author">
						<?php
						if(isset ($validation) && $validation->hasError('author')) 
						 {
						 	echo '<p style="color:red">'.$validation->getError('author').'</p>';
						 	
						 }

						?>
					</div>

					<div class="form-group">
						<label>Isbn_no</label>
						<input type="text" name="isbn_no" class="form-control" id="isbn_no" placeholder="Isbn_no" 
							value="">
					</div>

					<div class="form-group">
						<button type="submit" name="submit" class="btn btn-success">submit</button>
					
						<a href="<?php echo base_url('books/') ?>" class="btn btn-warning">Cancel</a>
					</div>
					</form>	

				</div>			
			</div>
			</div>
		</div>
	</div>

</div>
</body>
</html>